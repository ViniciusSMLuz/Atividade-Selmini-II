
public class ClassProduto {
    int estoque = 0;
    double pre�o = 0;
    String nome = "";
}
